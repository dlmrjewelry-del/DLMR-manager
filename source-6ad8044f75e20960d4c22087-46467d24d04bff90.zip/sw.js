// sw.js - Service Worker para DLMR MANAGER PWA
const CACHE_NAME = 'dlmr-manager-v2';

const PRECACHE_ASSETS = [
  '/',
  '/index.html',
  '/manifest.webmanifest',
  '/manifest.json',
  '/icons/icon.svg',
  '/icons/icon-192.png',
  '/icons/icon-512.png',
  '/icons/icon-maskable-192.png',
  '/icons/icon-maskable-512.png',
  '/icons/apple-touch-icon.png',
  '/icons/favicon-32.png'
];

// Instalación: Precacheo de la interfaz y recursos principales
self.addEventListener('install', (event) => {
  event.waitUntil(
    caches.open(CACHE_NAME).then((cache) => {
      return cache.addAll(PRECACHE_ASSETS);
    }).then(() => self.skipWaiting())
  );
});

// Activación: Limpieza segura de cachés anteriores sin tocar datos de la app
self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches.keys().then((keys) => {
      return Promise.all(
        keys.map((key) => {
          if (key !== CACHE_NAME) {
            return caches.delete(key);
          }
        })
      );
    }).then(() => self.clients.claim())
  );
});

// Peticiones de red
self.addEventListener('fetch', (event) => {
  const url = new URL(event.request.url);

  // 1. Excluir sincronización de Firebase y websockets
  if (url.hostname.includes('firebaseio.com') || url.protocol.startsWith('ws')) {
    return;
  }

  // 2. Excluir peticiones de funciones Netlify (asistente IA, subida de fotos, notificaciones)
  if (url.pathname.includes('/.netlify/functions/') || url.pathname.startsWith('/api/')) {
    return;
  }

  // 3. Manejar solo peticiones GET
  if (event.request.method !== 'GET') {
    return;
  }

  // 4. Navegación: Network-first con respaldo en caché (permite abrir la app sin conexión)
  if (event.request.mode === 'navigate') {
    event.respondWith(
      fetch(event.request)
        .then((response) => {
          if (response && response.status === 200) {
            const responseClone = response.clone();
            caches.open(CACHE_NAME).then((cache) => {
              cache.put(event.request, responseClone);
            });
          }
          return response;
        })
        .catch(() => {
          return caches.match('/index.html') || caches.match('/');
        })
    );
    return;
  }

  // 5. CDNs externos (Tailwind CSS, FontAwesome, Firebase SDK): Stale-While-Revalidate
  if (
    url.hostname.includes('cdn.tailwindcss.com') ||
    url.hostname.includes('cdnjs.cloudflare.com') ||
    url.hostname.includes('gstatic.com')
  ) {
    event.respondWith(
      caches.match(event.request).then((cachedResponse) => {
        if (cachedResponse) {
          fetch(event.request).then((networkResponse) => {
            if (networkResponse && networkResponse.status === 200) {
              caches.open(CACHE_NAME).then((cache) => {
                cache.put(event.request, networkResponse);
              });
            }
          }).catch(() => {});
          return cachedResponse;
        }

        return fetch(event.request).then((networkResponse) => {
          if (networkResponse && networkResponse.status === 200) {
            const responseClone = networkResponse.clone();
            caches.open(CACHE_NAME).then((cache) => {
              cache.put(event.request, responseClone);
            });
          }
          return networkResponse;
        }).catch(() => caches.match(event.request));
      })
    );
    return;
  }

  // 6. Recursos estáticos locales
  event.respondWith(
    caches.match(event.request).then((cachedResponse) => {
      if (cachedResponse) {
        return cachedResponse;
      }
      return fetch(event.request).then((networkResponse) => {
        if (!networkResponse || networkResponse.status !== 200 || networkResponse.type !== 'basic') {
          return networkResponse;
        }
        const responseClone = networkResponse.clone();
        caches.open(CACHE_NAME).then((cache) => {
          cache.put(event.request, responseClone);
        });
        return networkResponse;
      });
    })
  );
});

// Soporte para Notificaciones Push en el Service Worker
self.addEventListener('push', (event) => {
  let data = {};
  if (event.data) {
    try {
      data = event.data.json();
    } catch (e) {
      data = { body: event.data.text() };
    }
  }

  const title = data.title || '💎 DLMR MANAGER';
  const tag = data.tag || ('dlmr-' + (data.id || Date.now()));
  const options = {
    body: data.body || 'Nuevo registro en el sistema.',
    icon: data.icon || '/icons/icon-192.png',
    badge: data.badge || '/icons/favicon-32.png',
    vibrate: [200, 100, 200],
    tag: tag,
    renotify: true,
    requireInteraction: false,
    data: data.data || { url: '/' }
  };

  event.waitUntil(
    self.registration.showNotification(title, options).then(() => {
      // Notificar a pestañas abiertas si existen
      return clients.matchAll({ type: 'window', includeUncontrolled: true }).then((clientList) => {
        for (const client of clientList) {
          client.postMessage({
            type: 'DLMR_PUSH_RECEIVED',
            notification: { title, ...options }
          });
        }
      });
    })
  );
});

self.addEventListener('notificationclick', (event) => {
  event.notification.close();
  const targetUrl = (event.notification.data && event.notification.data.url) ? event.notification.data.url : '/';

  event.waitUntil(
    clients.matchAll({ type: 'window', includeUncontrolled: true }).then((clientList) => {
      for (const client of clientList) {
        if ('focus' in client) {
          if (client.url.includes(self.location.origin) || client.url.includes('/')) {
            return client.focus();
          }
        }
      }
      if (clients.openWindow) {
        return clients.openWindow(targetUrl);
      }
    })
  );
});
