// test/verify-all.mjs
// Suite de verificación automática para DLMR MANAGER

import fs from 'fs';
import path from 'path';
import assert from 'assert';

console.log('--- INICIANDO VERIFICACIÓN COMPLETA DE DLMR MANAGER ---');

let passedTests = 0;
let totalTests = 0;

function test(name, fn) {
  totalTests++;
  try {
    fn();
    console.log(`[PASS] Test ${totalTests}: ${name}`);
    passedTests++;
  } catch (err) {
    console.error(`[FAIL] Test ${totalTests}: ${name}`);
    console.error(`       Error: ${err.message}`);
  }
}

async function asyncTest(name, fn) {
  totalTests++;
  try {
    await fn();
    console.log(`[PASS] Test ${totalTests}: ${name}`);
    passedTests++;
  } catch (err) {
    console.error(`[FAIL] Test ${totalTests}: ${name}`);
    console.error(`       Error: ${err.message}`);
  }
}

// ---------------------------------------------------------------------
// 1. VERIFICACIÓN DE MANIFIESTO PWA Y ARCHIVOS ESTÁTICOS
// ---------------------------------------------------------------------
test('PWA Manifest es válido y contiene los campos requeridos', () => {
  const manifestRaw = fs.readFileSync('manifest.webmanifest', 'utf-8');
  const manifest = JSON.parse(manifestRaw);
  assert.strictEqual(manifest.name, 'DLMR MANAGER');
  assert.strictEqual(manifest.short_name, 'DLMR');
  assert.strictEqual(manifest.display, 'standalone');
  assert.strictEqual(manifest.start_url, '/');
  assert.strictEqual(manifest.theme_color, '#d4af37');
  assert.strictEqual(manifest.background_color, '#0b1120');
  assert(Array.isArray(manifest.icons) && manifest.icons.length >= 4);

  // Verificar que los iconos existan en el sistema de archivos
  for (const icon of manifest.icons) {
    const iconPath = icon.src.replace(/^\//, '');
    assert(fs.existsSync(iconPath), `Icono no encontrado: ${iconPath}`);
    assert(fs.statSync(iconPath).size > 0, `Icono vacío: ${iconPath}`);
  }
});

test('manifest.json existe y coincide con manifest.webmanifest', () => {
  const jsonRaw = fs.readFileSync('manifest.json', 'utf-8');
  const manifestJson = JSON.parse(jsonRaw);
  assert.strictEqual(manifestJson.name, 'DLMR MANAGER');
  assert.strictEqual(manifestJson.short_name, 'DLMR');
});

test('Service Worker (sw.js) está presente y no contiene credenciales sensibles', () => {
  const swCode = fs.readFileSync('sw.js', 'utf-8');
  assert(swCode.includes("const CACHE_NAME = 'dlmr-manager-v2'"));
  assert(swCode.includes('firebaseio.com'), 'Debe excluir endpoints de Firebase de la caché');
  assert(!swCode.includes('AIzaSy'), 'No debe contener claves API en la caché');
  assert(!swCode.includes('1234'), 'No debe contener PIN hardcodeado');
});

// ---------------------------------------------------------------------
// 2. LÓGICA DE CAMBIO DE PIN DE ADMINISTRADOR
// ---------------------------------------------------------------------
test('Cambio de PIN de Administrador valida PIN actual y nuevo PIN', () => {
  let state = { adminPin: "1234", customPins: { "5678": { name: "Suly" } } };

  // Función de validación y cambio
  function changeAdminPin(currentInput, newPin, confirmPin) {
    const actualCurrent = state.adminPin || "1234";
    if (currentInput !== actualCurrent) return { ok: false, error: 'PIN actual incorrecto' };
    if (!/^\d{4,6}$/.test(newPin)) return { ok: false, error: 'Nuevo PIN inválido' };
    if (newPin !== confirmPin) return { ok: false, error: 'Confirmación no coincide' };
    if (state.customPins && state.customPins[newPin]) return { ok: false, error: 'PIN usado por colaborador' };
    state.adminPin = newPin;
    return { ok: true };
  }

  // Intento con PIN actual incorrecto
  assert.strictEqual(changeAdminPin("0000", "9999", "9999").ok, false);
  assert.strictEqual(state.adminPin, "1234");

  // Intento con PIN no numérico o longitud incorrecta
  assert.strictEqual(changeAdminPin("1234", "12", "12").ok, false);
  assert.strictEqual(changeAdminPin("1234", "abcde", "abcde").ok, false);

  // Intento con confirmación dispareja
  assert.strictEqual(changeAdminPin("1234", "9999", "9998").ok, false);

  // Intento usando PIN de colaborador existente
  assert.strictEqual(changeAdminPin("1234", "5678", "5678").ok, false);

  // Cambio exitoso
  const resSuccess = changeAdminPin("1234", "8888", "8888");
  assert.strictEqual(resSuccess.ok, true);
  assert.strictEqual(state.adminPin, "8888");
});

// ---------------------------------------------------------------------
// 3. CÁLCULO DE COMISIONES POR CANTIDAD (L 25 POR ARTÍCULO) Y ANTI-DUPLICACIÓN
// ---------------------------------------------------------------------
test('Cálculo de comisiones con cantidad (1=25, 2=50, 3=75, 4=100, 5=125)', () => {
  function computeCommission(quantity) {
    const qty = parseInt(quantity, 10) || 1;
    return qty * 25.00;
  }

  assert.strictEqual(computeCommission(1), 25.00);
  assert.strictEqual(computeCommission(2), 50.00);
  assert.strictEqual(computeCommission(3), 75.00);
  assert.strictEqual(computeCommission(4), 100.00);
  assert.strictEqual(computeCommission(5), 125.00);
});

test('Totales del negocio, liquidaciones y retrocompatibilidad con registros antiguos', () => {
  const items = [
    // Registro antiguo (sin campo quantity, con commission = 25)
    { id: '1', collabName: 'Suly', itemDesc: 'Arito clásico', salePrice: 155.00, commission: 25.00 },
    // Registro nuevo con cantidad = 3 (unitPrice: 100, salePrice: 300, commission: 75)
    { id: '2', collabName: 'Suly', itemDesc: 'Pulsera triple', quantity: 3, unitPrice: 100.00, salePrice: 300.00, commission: 75.00 },
    // Registro nuevo con cantidad = 2
    { id: '3', collabName: 'Suly', itemDesc: 'Cadena oro', quantity: 2, unitPrice: 200.00, salePrice: 400.00, commission: 50.00 }
  ];

  let totalVenta = 0;
  let totalComision = 0;
  let totalArticulos = 0;

  items.forEach(item => {
    const qty = item.quantity || 1;
    // REGLA CLAVE: no multiplicar dos veces. Si item.commission está definido, se suma directamente
    const comision = (item.commission != null) ? item.commission : (qty * 25.00);
    totalVenta += item.salePrice;
    totalComision += comision;
    totalArticulos += qty;
  });

  assert.strictEqual(totalArticulos, 1 + 3 + 2); // 6 artículos
  assert.strictEqual(totalVenta, 155 + 300 + 400); // L 855.00
  assert.strictEqual(totalComision, 25 + 75 + 50); // L 150.00 (6 * 25)
  assert.strictEqual(totalVenta - totalComision, 705.00); // Neto negocio: L 705.00
});

// ---------------------------------------------------------------------
// 4. CORRECCIÓN DEL BORRADO: DATOS PERMANENTES SOBREVIVEN A LIQUIDACIONES
// ---------------------------------------------------------------------
test('Al liquidar ventas, los datos y nombres de colaboradores no se borran', () => {
  let state = {
    colaboradoresList: [{ name: 'Suly' }, { name: 'Verónica' }],
    customPins: { "5678": { name: 'Suly' }, "9012": { name: 'Verónica' } },
    colaboradores: [
      { id: 'art1', collabName: 'Suly', itemDesc: 'Arito', salePrice: 155, commission: 25 },
      { id: 'art2', collabName: 'Suly', itemDesc: 'Pulsera', salePrice: 200, commission: 25 },
      { id: 'art3', collabName: 'Verónica', itemDesc: 'Cadena', salePrice: 300, commission: 25 }
    ],
    historialPagos: []
  };

  // Simular liquidación exclusiva para Suly
  const collabName = 'Suly';
  const itemsToPay = state.colaboradores.filter(i => i.collabName === collabName);

  const pago = {
    id: 'pago_123',
    collabName,
    fecha: new Date().toISOString(),
    totalVenta: itemsToPay.reduce((s, i) => s + i.salePrice, 0),
    totalComision: itemsToPay.reduce((s, i) => s + i.commission, 0),
    totalArticulos: itemsToPay.length,
    articulos: itemsToPay
  };

  state.historialPagos.push(pago);

  // Eliminar únicamente los artículos de Suly
  const paidIds = new Set(itemsToPay.map(i => i.id));
  state.colaboradores = state.colaboradores.filter(i => !paidIds.has(i.id));

  // Verificaciones críticas:
  // 1. Suly sigue en colaboradoresList
  assert(state.colaboradoresList.some(c => c.name === 'Suly'), 'El colaborador Suly debe permanecer registrado');
  // 2. Suly sigue en customPins
  assert.strictEqual(state.customPins['5678'].name, 'Suly', 'El PIN de Suly debe permanecer intacto');
  // 3. Las ventas de Verónica siguen intactas
  assert.strictEqual(state.colaboradores.length, 1);
  assert.strictEqual(state.colaboradores[0].collabName, 'Verónica');
  assert.strictEqual(state.colaboradores[0].itemDesc, 'Cadena');
  // 4. El pago quedó registrado en el historial
  assert.strictEqual(state.historialPagos.length, 1);
  assert.strictEqual(state.historialPagos[0].totalComision, 50);
});

// ---------------------------------------------------------------------
// 5. SEGURIDAD: COLABORADORES NO PUEDEN EJECUTAR ACCIONES DE ADMIN
// ---------------------------------------------------------------------
test('Colaboradores no pueden ejecutar pagos de comisión ni cambio de PIN admin', () => {
  const collabSession = { role: 'collab', name: 'Suly' };

  function pagarComision(session) {
    if (!session || session.role !== 'admin') {
      return { ok: false, error: 'No autorizado' };
    }
    return { ok: true };
  }

  function cambiarAdminPin(session) {
    if (!session || session.role !== 'admin') {
      return { ok: false, error: 'No autorizado' };
    }
    return { ok: true };
  }

  assert.strictEqual(pagarComision(collabSession).ok, false);
  assert.strictEqual(cambiarAdminPin(collabSession).ok, false);

  const adminSession = { role: 'admin', name: 'Delmer' };
  assert.strictEqual(pagarComision(adminSession).ok, true);
  assert.strictEqual(cambiarAdminPin(adminSession).ok, true);
});

// ---------------------------------------------------------------------
// 5b. CONTROL DE PAGOS Y ABONOS DE IMPORTACIONES (REQUISITOS 1, 2, 3, 4, 5, 6)
// ---------------------------------------------------------------------
test('Control de pagos y abonos: cálculo de saldo pendiente y estados automáticos', () => {
  // Datos de prueba separados sin tocar datos reales
  const mockState = {
    importaciones: [
      { id: 'imp_1', clientName: 'ClientePrueba', itemDesc: 'Vestido', total: 600.00 },
      { id: 'imp_2', clientName: 'ClientePrueba', itemDesc: 'Zapatos', total: 400.00 }
    ],
    importPagos: []
  };

  function getSummary(clientName, state) {
    const items = state.importaciones.filter(i => i.clientName === clientName);
    const totalFactura = items.reduce((acc, it) => acc + (parseFloat(it.total) || 0), 0);
    const pagos = state.importPagos.filter(p => p.clientName === clientName);
    const totalAbonado = pagos.reduce((acc, p) => acc + (parseFloat(p.monto) || 0), 0);
    const saldoPendiente = Math.max(0, Math.round((totalFactura - totalAbonado) * 100) / 100);

    let estado = 'Pendiente';
    if (pagos.length > 0) {
      if (saldoPendiente <= 0.001 && totalFactura > 0 && totalAbonado >= totalFactura) {
        estado = 'Pagado / Cobrado';
      } else if (totalAbonado > 0) {
        estado = 'Abono parcial';
      }
    }

    const pagosOrdenados = [...pagos].sort((a, b) => new Date(b.fecha || 0) - new Date(a.fecha || 0));
    const ultimoPago = pagosOrdenados.length > 0 ? pagosOrdenados[0] : null;

    return { totalFactura, totalAbonado, saldoPendiente, estado, ultimoPago, pagos: pagosOrdenados };
  }

  // 1. Factura nueva sin abonos -> Estado: Pendiente, saldo = total
  const res1 = getSummary('ClientePrueba', mockState);
  assert.strictEqual(res1.totalFactura, 1000.00);
  assert.strictEqual(res1.totalAbonado, 0.00);
  assert.strictEqual(res1.saldoPendiente, 1000.00);
  assert.strictEqual(res1.estado, 'Pendiente');

  // 2. Facturas antiguas sin pagos no deben marcarse como pagadas
  assert.strictEqual(res1.estado, 'Pendiente', 'Facturas sin pagos registrados deben permanecer Pendientes');

  // 3. Registrar un abono parcial de L 350
  mockState.importPagos.push({
    id: 'pago_1',
    clientName: 'ClientePrueba',
    monto: 350.00,
    metodo: 'Transferencia bancaria',
    fecha: '2026-10-20T10:00:00.000Z',
    fechaFormateada: '20/10/2026, 10:00 a.m.'
  });

  const res2 = getSummary('ClientePrueba', mockState);
  assert.strictEqual(res2.totalFactura, 1000.00);
  assert.strictEqual(res2.totalAbonado, 350.00);
  assert.strictEqual(res2.saldoPendiente, 650.00, 'Saldo pendiente debe ser 1000 - 350 = 650');
  assert.strictEqual(res2.estado, 'Abono parcial');
  assert.strictEqual(res2.ultimoPago.monto, 350.00);

  // 4. Registrar segundo abono de L 250
  mockState.importPagos.push({
    id: 'pago_2',
    clientName: 'ClientePrueba',
    monto: 250.00,
    metodo: 'Efectivo',
    fecha: '2026-10-20T14:30:00.000Z',
    fechaFormateada: '20/10/2026, 2:30 p.m.'
  });

  const res3 = getSummary('ClientePrueba', mockState);
  assert.strictEqual(res3.totalAbonado, 600.00);
  assert.strictEqual(res3.saldoPendiente, 400.00);
  assert.strictEqual(res3.estado, 'Abono parcial');
  assert.strictEqual(res3.ultimoPago.id, 'pago_2', 'El último pago debe ser el más reciente');

  // 5. Registrar el pago del saldo restante (L 400.00)
  mockState.importPagos.push({
    id: 'pago_3',
    clientName: 'ClientePrueba',
    monto: 400.00,
    metodo: 'Depósito bancario',
    fecha: '2026-10-20T16:00:00.000Z',
    fechaFormateada: '20/10/2026, 4:00 p.m.'
  });

  const res4 = getSummary('ClientePrueba', mockState);
  assert.strictEqual(res4.totalAbonado, 1000.00);
  assert.strictEqual(res4.saldoPendiente, 0.00);
  assert.strictEqual(res4.estado, 'Pagado / Cobrado');
});

test('Validaciones de registro de pago: no negativos, no exceder saldo y prevención de duplicados', () => {
  const summary = { totalFactura: 500.00, totalAbonado: 200.00, saldoPendiente: 300.00 };

  function validatePayment(monto, summary, recentPayments) {
    if (isNaN(monto) || monto <= 0) {
      return { ok: false, error: 'Monto debe ser mayor a cero' };
    }
    if (monto > summary.saldoPendiente + 0.001) {
      return { ok: false, error: 'Monto supera el saldo pendiente' };
    }
    // Anti-duplicado en ventana de 3 segundos
    const now = Date.now();
    const esDup = recentPayments.some(p => Math.abs(p.monto - monto) < 0.001 && (now - p.time) < 3000);
    if (esDup) {
      return { ok: false, error: 'Pago duplicado detectado' };
    }
    return { ok: true };
  }

  // Rechazo de montos negativos o en cero
  assert.strictEqual(validatePayment(-50, summary, []).ok, false);
  assert.strictEqual(validatePayment(0, summary, []).ok, false);

  // Rechazo de montos mayores al saldo pendiente (saldo es 300, intenta pagar 350)
  assert.strictEqual(validatePayment(350, summary, []).ok, false);

  // Aceptación de pago válido (ej: abono de 150)
  assert.strictEqual(validatePayment(150, summary, []).ok, true);

  // Aceptación de pago exacto del saldo restante (300)
  assert.strictEqual(validatePayment(300, summary, []).ok, true);

  // Prevención de duplicado
  const recent = [{ monto: 150, time: Date.now() - 500 }];
  assert.strictEqual(validatePayment(150, summary, recent).ok, false);
});

test('Comprobante de WhatsApp: Factura inicial vs Comprobante actualizado con abonos y saldos', () => {
  function generateWhatsAppText(clientName, items, summary) {
    let msg = '';
    if (summary.pagos.length === 0) {
      msg = `✨ *DLMR JEWELRY - Factura de Importación* ✨\nCliente: *${clientName}*\n`;
      items.forEach((it, idx) => { msg += `${idx + 1}. ${it.itemDesc} — *L ${it.total.toFixed(2)}*\n`; });
      msg += `*TOTAL FACTURA: L ${summary.totalFactura.toFixed(2)}*\n*TOTAL A PAGAR: L ${summary.totalFactura.toFixed(2)}*\n*Estado de Pago: PENDIENTE*\n*Saldo Pendiente: L ${summary.totalFactura.toFixed(2)}*`;
    } else {
      msg = `🧾 *DLMR JEWELRY - Comprobante de Importación* 🧾\nCliente: *${clientName}*\n`;
      items.forEach((it, idx) => { msg += `${idx + 1}. ${it.itemDesc} — *L ${it.total.toFixed(2)}*\n`; });
      msg += `*TOTAL FACTURA: L ${summary.totalFactura.toFixed(2)}*\n*TOTAL ABONADO: L ${summary.totalAbonado.toFixed(2)}*\n*SALDO PENDIENTE: L ${summary.saldoPendiente.toFixed(2)}*\n*ESTADO DEL PAGO: ${summary.estado.toUpperCase()}*\n*Fecha del Último Pago:* ${summary.ultimoPago.fechaFormateada} - L ${summary.ultimoPago.monto.toFixed(2)}`;
    }
    return msg;
  }

  const items = [{ itemDesc: 'Cartera de cuero', total: 800 }];

  // 1. Factura nueva
  const summaryNuevo = { totalFactura: 800, totalAbonado: 0, saldoPendiente: 800, estado: 'Pendiente', pagos: [] };
  const txtNueva = generateWhatsAppText('Ana', items, summaryNuevo);
  assert(txtNueva.includes('Factura de Importación'));
  assert(txtNueva.includes('TOTAL FACTURA: L 800.00'));
  assert(txtNueva.includes('PENDIENTE'));

  // 2. Comprobante actualizado con abono
  const summaryAbono = {
    totalFactura: 800,
    totalAbonado: 300,
    saldoPendiente: 500,
    estado: 'Abono parcial',
    ultimoPago: { fechaFormateada: '20/10/2026, 3:00 p.m.', monto: 300 },
    pagos: [{ id: 'p1' }]
  };
  const txtAbono = generateWhatsAppText('Ana', items, summaryAbono);
  assert(txtAbono.includes('Comprobante de Importación'));
  assert(txtAbono.includes('TOTAL FACTURA: L 800.00'));
  assert(txtAbono.includes('TOTAL ABONADO: L 300.00'));
  assert(txtAbono.includes('SALDO PENDIENTE: L 500.00'));
  assert(txtAbono.includes('ABONO PARCIAL'));
  assert(txtAbono.includes('20/10/2026, 3:00 p.m.'));
});

test('Seguridad de permisos: exclusividad absoluta del Administrador en pagos y saldos de importaciones', () => {
  const adminSession = { role: 'admin', name: 'Delmer' };
  const collabSession = { role: 'collab', name: 'Zalma' };

  function checkAdminOnlyAction(session) {
    if (!session || session.role !== 'admin') {
      return { allowed: false, error: 'Acceso restringido: Exclusivo del Administrador' };
    }
    return { allowed: true };
  }

  // Colaborador bloqueado
  assert.strictEqual(checkAdminOnlyAction(collabSession).allowed, false);
  assert.strictEqual(checkAdminOnlyAction(null).allowed, false);

  // Administrador autorizado
  assert.strictEqual(checkAdminOnlyAction(adminSession).allowed, true);
});

// ---------------------------------------------------------------------
// 6. VERIFICACIÓN DE FUNCIONES NETLIFY (BACKEND SERVERLESS)
// ---------------------------------------------------------------------
asyncTest('netlify/functions/notify-admin procesa eventos de nuevas ventas', async () => {
  const notifyModule = await import('../netlify/functions/notify-admin.js');
  const handler = notifyModule.default;

  const mockReq = new Request('http://localhost/api/notify-admin', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      collabName: 'Suly',
      itemDesc: 'Arito perla',
      quantity: 2,
      salePrice: 310,
      commission: 50,
      timestamp: new Date().toISOString()
    })
  });

  const res = await handler(mockReq);
  assert.strictEqual(res.status, 200);
  const data = await res.json();
  assert.strictEqual(data.success, true);
  assert(data.notification.title.includes('Suly'), 'El título debe incluir el nombre del colaborador');
  assert(data.notification.body.includes('Arito perla'), 'El cuerpo debe incluir la descripción del artículo');
  assert(data.notification.body.includes('2x'), 'El cuerpo debe incluir la cantidad registrada');
  assert(data.notification.tag.startsWith('dlmr-sale-'), 'Debe incluir una etiqueta tag para evitar duplicados');
  assert(data.notification.data.registeredAt, 'Debe incluir fecha y hora del registro');
});

asyncTest('netlify/functions/notify-admin expone clave pública VAPID y maneja suscripciones', async () => {
  const notifyModule = await import('../netlify/functions/notify-admin.js');
  const handler = notifyModule.default;

  // 1. GET vapidPublicKey
  const getReq = new Request('http://localhost/api/notify-admin?action=status');
  const getRes = await handler(getReq);
  assert.strictEqual(getRes.status, 200);
  const getData = await getRes.json();
  assert(getData.vapidPublicKey, 'Debe exponer vapidPublicKey para registro en cliente');

  // 2. POST acción subscribe
  const subReq = new Request('http://localhost/api/notify-admin', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      action: 'subscribe',
      subscription: {
        endpoint: 'https://fcm.googleapis.com/fcm/send/test-verification-token',
        keys: {
          p256dh: 'BLfVUX_aziQiGk0U2DGQZ3og7ffC6U1d_l76-NrZCF5rwVGCXzkKu0-2OsIppw84T_N3greiSlbL9jx6vTl1piQ',
          auth: 'MTIzNDU2Nzg5MDEyMzQ1Ng'
        }
      }
    })
  });
  const subRes = await handler(subReq);
  assert.strictEqual(subRes.status, 200);
  const subData = await subRes.json();
  assert.strictEqual(subData.success, true);
});

test('index.html y sw.js integran Web Push real y prevención de duplicados', () => {
  const indexHtml = fs.readFileSync('index.html', 'utf-8');
  const swCode = fs.readFileSync('sw.js', 'utf-8');

  assert(indexHtml.includes('DLMR_VAPID_PUBLIC_KEY'), 'index.html debe configurar la clave VAPID pública');
  assert(indexHtml.includes('ensureAdminPushSubscribed'), 'index.html debe incluir la función para suscribir el celular a Web Push');
  assert(indexHtml.includes('adminNotifModal'), 'index.html debe tener el modal de gestión de notificaciones');
  assert(indexHtml.includes('triggerTestNotification'), 'index.html debe permitir enviar una notificación de prueba real');

  assert(swCode.includes("addEventListener('push'"), 'sw.js debe escuchar eventos push de la red');
  assert(swCode.includes('tag:'), 'sw.js debe etiquetar las notificaciones para evitar duplicados');
  assert(swCode.includes('renotify: true'), 'sw.js debe usar renotify para alertar en actualizaciones');
});

asyncTest('netlify/functions/gemini-chat responde con Google Gemini real', async () => {
  const geminiModule = await import('../netlify/functions/gemini-chat.js');
  const handler = geminiModule.default;

  const mockReq = new Request('http://localhost/api/gemini-chat', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      message: '¿Cuánto es la comisión de 3 artículos según las reglas de DLMR MANAGER?'
    })
  });

  const res = await handler(mockReq);
  assert.strictEqual(res.status, 200);
  const data = await res.json();
  assert(data.reply, 'Debe devolver un campo reply');
  assert(data.reply.includes('75'), `La respuesta de Gemini debe mencionar L 75. Recibido: ${data.reply}`);
});

test('Clave privada GEMINI_API_KEY no está expuesta en archivos cliente', () => {
  const indexHtml = fs.readFileSync('index.html', 'utf-8');
  assert(!indexHtml.includes(process.env.GEMINI_API_KEY || 'N/A'), 'GEMINI_API_KEY no debe estar en index.html');
  assert(!indexHtml.includes(process.env.NETLIFY_AI_GATEWAY_KEY || 'N/A'), 'Gateway key no debe estar en index.html');
  assert(indexHtml.includes('/.netlify/functions/gemini-chat'), 'El cliente debe llamar al endpoint serverless');
});

console.log('--- FINALIZANDO PRUEBAS ---');
setTimeout(() => {
  console.log(`\nRESULTADOS: ${passedTests} de ${totalTests} pruebas superadas.`);
  if (passedTests === totalTests) {
    console.log('¡TODAS LAS PRUEBAS PASARON EXITOSAMENTE!');
    process.exit(0);
  } else {
    console.error('ALGUNAS PRUEBAS FALLARON');
    process.exit(1);
  }
}, 3000);
