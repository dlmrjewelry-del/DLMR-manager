// netlify/functions/notify-admin.js
// Sistema de Notificaciones Push Web reales para el Administrador de DLMR MANAGER

import webpush from './lib/webpush.js';

const VAPID_PUBLIC_KEY = 'BLfVUX_aziQiGk0U2DGQZ3og7ffC6U1d_l76-NrZCF5rwVGCXzkKu0-2OsIppw84T_N3greiSlbL9jx6vTl1piQ';
const VAPID_PRIVATE_KEY = process.env.VAPID_PRIVATE_KEY || 'vfi6uoYsJ-vfFwK5J5iaa_z7QB-XlkmiQTzADEglKXY';
const VAPID_SUBJECT = 'mailto:admin@dlmrjewelry.com';

try {
  webpush.setVapidDetails(VAPID_SUBJECT, VAPID_PUBLIC_KEY, VAPID_PRIVATE_KEY);
} catch (e) {
  console.warn('VAPID setup warning:', e.message);
}

const FIREBASE_DB_URL = process.env.VITE_FIREBASE_DATABASE_URL || 'https://dlmr-manager-default-rtdb.firebaseio.com';

function cleanFirebaseUrl(url) {
  return (url || '').replace(/\/$/, '');
}

function getSubKey(endpoint) {
  if (!endpoint) return 'sub_' + Date.now();
  return Buffer.from(endpoint).toString('base64url').slice(-40).replace(/[^a-zA-Z0-9_-]/g, '_');
}

// Recuperar suscripciones activas desde Firebase Realtime Database
async function getSubscriptionsFromFirebase() {
  try {
    const res = await fetch(`${cleanFirebaseUrl(FIREBASE_DB_URL)}/dlmr_admin_push_subscriptions.json`);
    if (!res.ok) return [];
    const data = await res.json();
    if (!data) return [];
    return Object.entries(data).map(([key, val]) => ({
      key,
      ...val
    })).filter(s => s && s.endpoint && s.keys && s.keys.p256dh && s.keys.auth);
  } catch (err) {
    console.warn('Error leyendo suscripciones de Firebase:', err.message);
    return [];
  }
}

// Guardar suscripción en Firebase
async function saveSubscriptionToFirebase(subKey, subData) {
  try {
    await fetch(`${cleanFirebaseUrl(FIREBASE_DB_URL)}/dlmr_admin_push_subscriptions/${subKey}.json`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(subData)
    });
  } catch (err) {
    console.warn('Error guardando suscripción en Firebase:', err.message);
  }
}

// Eliminar suscripción expirada o inválida de Firebase
async function deleteSubscriptionFromFirebase(subKey) {
  try {
    await fetch(`${cleanFirebaseUrl(FIREBASE_DB_URL)}/dlmr_admin_push_subscriptions/${subKey}.json`, {
      method: 'DELETE'
    });
  } catch (err) {
    console.warn('Error eliminando suscripción de Firebase:', err.message);
  }
}

// Recuperar suscripciones desde Netlify Blobs (persistencia secundaria)
async function getSubscriptionsFromBlobs() {
  try {
    const { getStore } = await import('@netlify/blobs');
    const store = getStore('dlmr-notifications');
    const subs = await store.get('admin-subscriptions', { type: 'json' });
    if (Array.isArray(subs)) {
      return subs.filter(s => s && s.endpoint && s.keys && s.keys.p256dh && s.keys.auth);
    }
  } catch (err) {}
  return [];
}

// Guardar suscripción en Netlify Blobs
async function saveSubscriptionToBlobs(subData) {
  try {
    const { getStore } = await import('@netlify/blobs');
    const store = getStore('dlmr-notifications');
    const current = (await store.get('admin-subscriptions', { type: 'json' })) || [];
    const filtered = current.filter(s => s.endpoint !== subData.endpoint);
    filtered.push(subData);
    await store.setJSON('admin-subscriptions', filtered);
  } catch (err) {}
}

// Eliminar suscripción de Netlify Blobs
async function removeSubscriptionFromBlobs(endpoint) {
  try {
    const { getStore } = await import('@netlify/blobs');
    const store = getStore('dlmr-notifications');
    const current = (await store.get('admin-subscriptions', { type: 'json' })) || [];
    const filtered = current.filter(s => s.endpoint !== endpoint);
    await store.setJSON('admin-subscriptions', filtered);
  } catch (err) {}
}

// Registrar historial de notificaciones en Firebase
async function logNotificationToFirebase(record) {
  try {
    const id = 'notif_' + Date.now() + '_' + Math.random().toString(36).substring(2, 6);
    await fetch(`${cleanFirebaseUrl(FIREBASE_DB_URL)}/dlmr_notification_history/${id}.json`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(record)
    });
  } catch (err) {}
}

function cleanCollabKey(name) {
  if (!name) return 'desconocido';
  return Buffer.from(name.trim().toLowerCase()).toString('base64url').replace(/[^a-zA-Z0-9_-]/g, '_');
}

// Recuperar suscripciones de un colaborador específico desde Firebase
async function getCollabSubscriptionsFromFirebase(collabName) {
  try {
    const key = cleanCollabKey(collabName);
    const res = await fetch(`${cleanFirebaseUrl(FIREBASE_DB_URL)}/dlmr_collab_push_subscriptions/${key}.json`);
    if (!res.ok) return [];
    const data = await res.json();
    if (!data) return [];
    return Object.entries(data).map(([subKey, val]) => ({
      key: subKey,
      ...val
    })).filter(s => s && s.endpoint && s.keys && s.keys.p256dh && s.keys.auth);
  } catch (err) {
    console.warn('Error leyendo suscripciones de colaborador en Firebase:', err.message);
    return [];
  }
}

// Guardar suscripción de un colaborador en Firebase
async function saveCollabSubscriptionToFirebase(collabName, subKey, subData) {
  try {
    const key = cleanCollabKey(collabName);
    await fetch(`${cleanFirebaseUrl(FIREBASE_DB_URL)}/dlmr_collab_push_subscriptions/${key}/${subKey}.json`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(subData)
    });
  } catch (err) {
    console.warn('Error guardando suscripción de colaborador en Firebase:', err.message);
  }
}

// Eliminar suscripción de colaborador expirada
async function deleteCollabSubscriptionFromFirebase(collabName, subKey) {
  try {
    const key = cleanCollabKey(collabName);
    await fetch(`${cleanFirebaseUrl(FIREBASE_DB_URL)}/dlmr_collab_push_subscriptions/${key}/${subKey}.json`, {
      method: 'DELETE'
    });
  } catch (err) {
    console.warn('Error eliminando suscripción de colaborador en Firebase:', err.message);
  }
}

// Persistencia en Blobs para colaboradores
async function getCollabSubscriptionsFromBlobs(collabName) {
  try {
    const { getStore } = await import('@netlify/blobs');
    const store = getStore('dlmr-notifications');
    const key = `collab-subs-${cleanCollabKey(collabName)}`;
    const subs = await store.get(key, { type: 'json' });
    if (Array.isArray(subs)) {
      return subs.filter(s => s && s.endpoint && s.keys && s.keys.p256dh && s.keys.auth);
    }
  } catch (err) {}
  return [];
}

async function saveCollabSubscriptionToBlobs(collabName, subData) {
  try {
    const { getStore } = await import('@netlify/blobs');
    const store = getStore('dlmr-notifications');
    const key = `collab-subs-${cleanCollabKey(collabName)}`;
    const current = (await store.get(key, { type: 'json' })) || [];
    const filtered = current.filter(s => s.endpoint !== subData.endpoint);
    filtered.push(subData);
    await store.setJSON(key, filtered);
  } catch (err) {}
}

async function removeCollabSubscriptionFromBlobs(collabName, endpoint) {
  try {
    const { getStore } = await import('@netlify/blobs');
    const store = getStore('dlmr-notifications');
    const key = `collab-subs-${cleanCollabKey(collabName)}`;
    const current = (await store.get(key, { type: 'json' })) || [];
    const filtered = current.filter(s => s.endpoint !== endpoint);
    await store.setJSON(key, filtered);
  } catch (err) {}
}

// Registrar notificación de pago de comisión a colaborador en Firebase
async function logCollabPaymentToFirebase(collabName, record) {
  try {
    const cKey = cleanCollabKey(collabName);
    const id = record.pagoId || ('pago_' + Date.now());
    await fetch(`${cleanFirebaseUrl(FIREBASE_DB_URL)}/dlmr_collab_notifications/${cKey}/${id}.json`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(record)
    });
  } catch (err) {}
}

// Enviar Push exclusivamente a los dispositivos del colaborador correspondiente
async function broadcastToCollabSubscriptions(collabName, payload) {
  const [fbSubs, blobSubs] = await Promise.all([
    getCollabSubscriptionsFromFirebase(collabName),
    getCollabSubscriptionsFromBlobs(collabName)
  ]);

  const subMap = new Map();
  for (const s of fbSubs) {
    if (s && s.endpoint) subMap.set(s.endpoint, s);
  }
  for (const s of blobSubs) {
    if (s && s.endpoint && !subMap.has(s.endpoint)) {
      subMap.set(s.endpoint, { ...s, key: getSubKey(s.endpoint) });
    }
  }

  const subscriptions = Array.from(subMap.values());
  const payloadString = typeof payload === 'string' ? payload : JSON.stringify(payload);

  let deliveredCount = 0;
  const deliveryErrors = [];

  for (const sub of subscriptions) {
    try {
      await webpush.sendNotification(
        {
          endpoint: sub.endpoint,
          keys: {
            p256dh: sub.keys.p256dh,
            auth: sub.keys.auth
          }
        },
        payloadString,
        {
          TTL: 86400,
          urgency: 'high'
        }
      );
      deliveredCount++;
    } catch (err) {
      console.warn(`Error enviando push a colaborador (${collabName}) en ${sub.endpoint.slice(0, 40)}...`, err.statusCode || err.message);
      deliveryErrors.push({ endpoint: sub.endpoint.slice(0, 40), error: err.message, status: err.statusCode });

      if (err.statusCode === 410 || err.statusCode === 404) {
        await Promise.all([
          deleteCollabSubscriptionFromFirebase(collabName, sub.key || getSubKey(sub.endpoint)),
          removeCollabSubscriptionFromBlobs(collabName, sub.endpoint)
        ]);
      }
    }
  }

  return {
    collabName,
    totalSubscriptions: subscriptions.length,
    deliveredCount,
    deliveryErrors
  };
}

// Enviar notificación Push a todas las suscripciones activas del administrador
async function broadcastToAdminSubscriptions(payload) {
  const [fbSubs, blobSubs] = await Promise.all([
    getSubscriptionsFromFirebase(),
    getSubscriptionsFromBlobs()
  ]);

  // Consolidar y deduplicar por endpoint
  const subMap = new Map();
  for (const s of fbSubs) {
    if (s && s.endpoint) subMap.set(s.endpoint, s);
  }
  for (const s of blobSubs) {
    if (s && s.endpoint && !subMap.has(s.endpoint)) {
      subMap.set(s.endpoint, { ...s, key: getSubKey(s.endpoint) });
    }
  }

  const subscriptions = Array.from(subMap.values());
  const payloadString = typeof payload === 'string' ? payload : JSON.stringify(payload);

  let deliveredCount = 0;
  const deliveryErrors = [];

  for (const sub of subscriptions) {
    try {
      await webpush.sendNotification(
        {
          endpoint: sub.endpoint,
          keys: {
            p256dh: sub.keys.p256dh,
            auth: sub.keys.auth
          }
        },
        payloadString,
        {
          TTL: 86400,
          urgency: 'high'
        }
      );
      deliveredCount++;
    } catch (err) {
      console.warn(`Error enviando push a ${sub.endpoint.slice(0, 40)}...`, err.statusCode || err.message);
      deliveryErrors.push({ endpoint: sub.endpoint.slice(0, 40), error: err.message, status: err.statusCode });

      // Si el endpoint ha expirado o ya no está registrado (410 Gone / 404 Not Found)
      if (err.statusCode === 410 || err.statusCode === 404) {
        console.log('Eliminando suscripción push caducada:', sub.endpoint.slice(0, 40));
        await Promise.all([
          deleteSubscriptionFromFirebase(sub.key || getSubKey(sub.endpoint)),
          removeSubscriptionFromBlobs(sub.endpoint)
        ]);
      }
    }
  }

  return {
    totalSubscriptions: subscriptions.length,
    deliveredCount,
    deliveryErrors
  };
}

// Formatear fecha y hora para la notificación
function formatNotificationDate(isoString) {
  try {
    const d = isoString ? new Date(isoString) : new Date();
    if (isNaN(d.getTime())) return new Date().toLocaleString();
    return d.toLocaleString('es-HN', {
      timeZone: 'America/Tegucigalpa',
      year: 'numeric',
      month: '2-digit',
      day: '2-digit',
      hour: '2-digit',
      minute: '2-digit',
      hour12: true
    });
  } catch (e) {
    return new Date().toISOString();
  }
}

export default async (req, context) => {
  // Manejo de preflight CORS
  if (req.method === 'OPTIONS') {
    return new Response(null, {
      status: 204,
      headers: {
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
        'Access-Control-Allow-Headers': 'Content-Type'
      }
    });
  }

  const url = new URL(req.url);

  // Endpoint GET: consultar clave pública VAPID o estado
  if (req.method === 'GET') {
    const action = url.searchParams.get('action');
    if (action === 'status') {
      const subs = await getSubscriptionsFromFirebase();
      return new Response(JSON.stringify({
        status: 'online',
        vapidPublicKey: VAPID_PUBLIC_KEY,
        subscriptionsCount: subs.length
      }), {
        status: 200,
        headers: { 'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*' }
      });
    }

    return new Response(JSON.stringify({
      vapidPublicKey: VAPID_PUBLIC_KEY
    }), {
      status: 200,
      headers: { 'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*' }
    });
  }

  if (req.method !== 'POST') {
    return new Response(JSON.stringify({ error: 'Método no permitido. Solo se acepta GET o POST.' }), {
      status: 405,
      headers: { 'Content-Type': 'application/json' }
    });
  }

  try {
    const data = await req.json().catch(() => ({}));
    const action = data.action || url.searchParams.get('action');

    // 1. ACCIÓN: Registrar suscripción Push del Administrador
    if (action === 'subscribe') {
      const subscription = data.subscription;
      if (!subscription || !subscription.endpoint || !subscription.keys) {
        return new Response(JSON.stringify({ error: 'Suscripción Web Push inválida.' }), {
          status: 400,
          headers: { 'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*' }
        });
      }

      const subKey = getSubKey(subscription.endpoint);
      const subRecord = {
        endpoint: subscription.endpoint,
        keys: subscription.keys,
        userAgent: data.userAgent || 'DLMR PWA Client',
        platform: data.platform || 'mobile',
        registeredAt: new Date().toISOString()
      };

      await Promise.all([
        saveSubscriptionToFirebase(subKey, subRecord),
        saveSubscriptionToBlobs(subRecord)
      ]);

      return new Response(JSON.stringify({
        success: true,
        message: 'Celular del administrador registrado exitosamente para Notificaciones Push.',
        subKey
      }), {
        status: 200,
        headers: { 'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*' }
      });
    }

    // 1b. ACCIÓN: Registrar suscripción Push de un Colaborador específico
    if (action === 'subscribe-collab') {
      const { subscription, collabName } = data;
      if (!collabName || !subscription || !subscription.endpoint || !subscription.keys) {
        return new Response(JSON.stringify({ error: 'Datos de suscripción o nombre de colaborador inválidos.' }), {
          status: 400,
          headers: { 'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*' }
        });
      }

      const subKey = getSubKey(subscription.endpoint);
      const subRecord = {
        collabName,
        endpoint: subscription.endpoint,
        keys: subscription.keys,
        userAgent: data.userAgent || 'DLMR PWA Client',
        platform: data.platform || 'mobile',
        registeredAt: new Date().toISOString()
      };

      await Promise.all([
        saveCollabSubscriptionToFirebase(collabName, subKey, subRecord),
        saveCollabSubscriptionToBlobs(collabName, subRecord)
      ]);

      return new Response(JSON.stringify({
        success: true,
        message: `Dispositivo registrado exitosamente para el colaborador ${collabName}.`,
        collabName,
        subKey
      }), {
        status: 200,
        headers: { 'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*' }
      });
    }

    // 2. ACCIÓN: Cancelar suscripción
    if (action === 'unsubscribe') {
      const endpoint = data.endpoint || (data.subscription && data.subscription.endpoint);
      if (endpoint) {
        const subKey = getSubKey(endpoint);
        await Promise.all([
          deleteSubscriptionFromFirebase(subKey),
          removeSubscriptionFromBlobs(endpoint)
        ]);
        if (data.collabName) {
          await Promise.all([
            deleteCollabSubscriptionFromFirebase(data.collabName, subKey),
            removeCollabSubscriptionFromBlobs(data.collabName, endpoint)
          ]);
        }
      }
      return new Response(JSON.stringify({ success: true, message: 'Suscripción cancelada.' }), {
        status: 200,
        headers: { 'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*' }
      });
    }

    // 3. ACCIÓN: Enviar notificación de prueba al Administrador
    if (action === 'test') {
      const testTimestamp = new Date().toISOString();
      const testFormattedDate = formatNotificationDate(testTimestamp);
      const payload = {
        title: '💎 DLMR MANAGER: Notificación de Prueba',
        body: `¡Las notificaciones al administrador están activas y funcionando! (${testFormattedDate})`,
        icon: '/icons/icon-192.png',
        badge: '/icons/favicon-32.png',
        tag: `dlmr-test-${Date.now()}`,
        timestamp: testTimestamp,
        data: { url: '/', type: 'test' }
      };

      const pushResult = await broadcastToAdminSubscriptions(payload);

      return new Response(JSON.stringify({
        success: true,
        message: pushResult.totalSubscriptions > 0 
          ? `Notificación de prueba enviada a ${pushResult.deliveredCount} dispositivo(s) registrado(s).`
          : 'No hay celulares de administrador registrados aún. Activa las notificaciones en el celular primero.',
        pushResult,
        notification: payload
      }), {
        status: 200,
        headers: { 'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*' }
      });
    }

    // 3b. ACCIÓN: Notificación de prueba exclusiva para Colaborador
    if (action === 'test-collab') {
      const collabName = data.collabName || 'Suly';
      const testTimestamp = new Date().toISOString();
      const testFormattedDate = formatNotificationDate(testTimestamp);
      const payload = {
        title: `💎 DLMR: Notificación para ${collabName}`,
        body: `¡Tus avisos de pago de comisiones están activos y listos! (${testFormattedDate})`,
        icon: '/icons/icon-192.png',
        badge: '/icons/favicon-32.png',
        tag: `dlmr-collab-test-${Date.now()}`,
        timestamp: testTimestamp,
        data: { url: '/', type: 'test-collab', collabName }
      };

      const pushResult = await broadcastToCollabSubscriptions(collabName, payload);

      return new Response(JSON.stringify({
        success: true,
        message: pushResult.totalSubscriptions > 0 
          ? `Notificación enviada a ${pushResult.deliveredCount} dispositivo(s) de ${collabName}.`
          : `No hay dispositivos registrados aún para ${collabName}.`,
        pushResult,
        notification: payload
      }), {
        status: 200,
        headers: { 'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*' }
      });
    }

    // 3c. ACCIÓN: Notificación de Pago de Comisión a Colaborador
    if (action === 'notify-collab-payment') {
      const { collabName, totalComision, totalArticulos, fechaFormateada, pagoId } = data;

      if (!collabName) {
        return new Response(JSON.stringify({ error: 'Falta el nombre del colaborador (collabName).' }), {
          status: 400,
          headers: { 'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*' }
        });
      }

      const comisionNum = Number(totalComision) || 0;
      const artCount = Number(totalArticulos) || 1;
      const fechaStr = fechaFormateada || formatNotificationDate(new Date().toISOString());
      const pId = pagoId || ('pago_' + Date.now() + '_' + Math.random().toString(36).substring(2, 6));

      // Notificación requerida por el usuario:
      // "indicar el monto pagado, la fecha y la cantidad de artículos liquidados."
      const notificationPayload = {
        title: `💎 DLMR: Comisión Pagada a ${collabName}`,
        body: `Monto pagado: L ${comisionNum.toFixed(2)} | ${artCount} artículo(s) liquidados | Fecha: ${fechaStr}`,
        icon: '/icons/icon-192.png',
        badge: '/icons/favicon-32.png',
        tag: `dlmr-collab-pago-${pId}`,
        timestamp: new Date().toISOString(),
        data: {
          url: '/',
          type: 'collab-payment',
          id: pId,
          collabName,
          totalComision: comisionNum,
          totalArticulos: artCount,
          fechaFormateada: fechaStr
        }
      };

      // Guardar en Firebase bajo el colaborador específico para sincronización persistente
      await logCollabPaymentToFirebase(collabName, notificationPayload);

      // Enviar Push exclusivamente a los dispositivos suscritos de ese colaborador
      const pushResult = await broadcastToCollabSubscriptions(collabName, notificationPayload);

      return new Response(JSON.stringify({
        success: true,
        message: `Notificación de pago de comisión procesada para ${collabName}.`,
        notification: notificationPayload,
        pushResult
      }), {
        status: 200,
        headers: { 'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*' }
      });
    }

    // 4. ACCIÓN: Evento de Nueva Venta registrada por Colaborador
    const { collabName, itemDesc, quantity, salePrice, commission, timestamp, id } = data;

    if (!collabName || !itemDesc) {
      return new Response(JSON.stringify({ error: 'Faltan datos obligatorios del artículo (collabName, itemDesc).' }), {
        status: 400,
        headers: { 'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*' }
      });
    }

    const qty = Number(quantity) || 1;
    const formattedDate = formatNotificationDate(timestamp);
    const saleId = id || (Date.now() + '_' + Math.random().toString(36).substring(2, 6));

    // Notificación formal con todos los datos requeridos por el usuario:
    // 1. Nombre del colaborador
    // 2. Descripción del artículo
    // 3. Cantidad
    // 4. Fecha y hora del registro
    const notificationPayload = {
      title: `💎 Nueva Venta: ${collabName}`,
      body: `${qty}x ${itemDesc} — ${formattedDate}`,
      icon: '/icons/icon-192.png',
      badge: '/icons/favicon-32.png',
      tag: `dlmr-sale-${saleId}`,
      timestamp: timestamp || new Date().toISOString(),
      data: {
        url: '/',
        id: saleId,
        collabName,
        itemDesc,
        quantity: qty,
        salePrice: Number(salePrice || 0),
        commission: Number(commission || (qty * 25)),
        registeredAt: formattedDate
      }
    };

    // Registrar en historial permanente de Firebase
    await logNotificationToFirebase({
      ...notificationPayload,
      receivedAt: new Date().toISOString()
    });

    // Enviar push a todos los celulares administradores registrados
    const pushResult = await broadcastToAdminSubscriptions(notificationPayload);

    return new Response(JSON.stringify({
      success: true,
      message: 'Notificación procesada y enviada a los celulares de administrador.',
      notification: notificationPayload,
      pushResult
    }), {
      status: 200,
      headers: { 'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*' }
    });

  } catch (err) {
    console.error('Error procesando notify-admin:', err);
    return new Response(JSON.stringify({ error: err.message }), {
      status: 500,
      headers: { 'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*' }
    });
  }
};
