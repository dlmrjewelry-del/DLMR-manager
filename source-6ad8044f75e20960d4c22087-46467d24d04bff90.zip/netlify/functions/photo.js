// netlify/functions/photo.js
// Recupera y sirve fotografías desde Netlify Blobs

export default async (req, context) => {
  const url = new URL(req.url);
  const id = url.searchParams.get('id');

  if (!id) {
    return new Response('ID de foto no especificado.', { status: 400 });
  }

  try {
    const { getStore } = await import('@netlify/blobs');
    const store = getStore('dlmr-photos');
    const data = await store.get(id);

    if (!data) {
      return new Response('Fotografía no encontrada.', { status: 404 });
    }

    // Si data es un dataURL (data:image/jpeg;base64,...)
    if (typeof data === 'string' && data.startsWith('data:')) {
      const parts = data.split(',');
      const mime = parts[0].match(/:(.*?);/)?.[1] || 'image/jpeg';
      const binary = Buffer.from(parts[1], 'base64');
      return new Response(binary, {
        status: 200,
        headers: {
          'Content-Type': mime,
          'Cache-Control': 'public, max-age=31536000, immutable'
        }
      });
    }

    return new Response(data, {
      status: 200,
      headers: {
        'Content-Type': 'image/jpeg',
        'Cache-Control': 'public, max-age=31536000, immutable'
      }
    });
  } catch (err) {
    return new Response('Error al recuperar fotografía: ' + err.message, { status: 500 });
  }
};
