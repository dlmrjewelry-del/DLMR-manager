// netlify/functions/upload-photo.js
// Almacena fotografías optimizadas en Netlify Blobs

export default async (req, context) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, {
      status: 204,
      headers: {
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Methods': 'POST, OPTIONS',
        'Access-Control-Allow-Headers': 'Content-Type'
      }
    });
  }

  if (req.method !== 'POST') {
    return new Response(JSON.stringify({ error: 'Método no permitido.' }), {
      status: 405,
      headers: { 'Content-Type': 'application/json' }
    });
  }

  try {
    const body = await req.json();
    const imageBase64 = body.image; // data:image/jpeg;base64,... o base64 puro
    if (!imageBase64) {
      return new Response(JSON.stringify({ error: 'No se envió ninguna imagen.' }), {
        status: 400,
        headers: { 'Content-Type': 'application/json' }
      });
    }

    const id = 'img_' + Date.now() + '_' + Math.random().toString(36).substring(2, 8);

    // Intentar almacenar en Netlify Blobs si está configurado
    try {
      const { getStore } = await import('@netlify/blobs');
      const store = getStore('dlmr-photos');
      await store.set(id, imageBase64);
      return new Response(JSON.stringify({
        success: true,
        id,
        url: `/.netlify/functions/photo?id=${id}`
      }), {
        status: 200,
        headers: { 'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*' }
      });
    } catch (blobErr) {
      // Si Blobs no está disponible (ej. entorno local sin credenciales), retornar la miniatura en base64 directamente
      return new Response(JSON.stringify({
        success: true,
        id,
        url: imageBase64
      }), {
        status: 200,
        headers: { 'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*' }
      });
    }
  } catch (err) {
    return new Response(JSON.stringify({ error: err.message }), {
      status: 500,
      headers: { 'Content-Type': 'application/json' }
    });
  }
};
