// netlify/functions/gemini-chat.js
// Asistente IA oficial de DLMR MANAGER con Google Gemini vía Netlify AI Gateway

const SYSTEM_PROMPT = `Eres el Asistente Virtual Inteligente de DLMR MANAGER (DLMR Jewelry).
Tu propósito es ayudar al administrador y a los colaboradores de DLMR Jewelry de forma concisa, educada, clara y profesional.

Conocimiento del negocio y de DLMR MANAGER:
1. Negocio: DLMR Jewelry se dedica a la comercialización y distribución de joyería fina, aritos de acero inoxidable, pulseras, collares, cadenas, así como importaciones de ropa y zapatos.
2. Comisiones de Colaboradores:
   - La comisión es fija de L 25 (Lempiras) por artículo vendido.
   - 1 artículo = L 25
   - 2 artículos = L 50
   - 3 artículos = L 75
   - 4 artículos = L 100
   - 5 artículos = L 125
   - Fórmula: cantidad × L 25.
   - El Neto del Negocio es: Total de Venta - Comisión Total.
3. Importaciones & Costos:
   - Aritos: Comisión sugerida +L 80 sobre el precio base.
   - Ropa: Comisión sugerida +L 150 sobre el precio base.
   - Zapatos: Comisión sugerida +L 200 sobre el precio base.
   - Otro / Personalizado: Definido por el administrador.
4. Funcionalidades en la aplicación:
   - Importaciones & Costos: Gestión de pedidos con cálculo automático de totales y facturas para WhatsApp.
   - Colaboradores & Ventas: Registro de ventas con descripción, cantidad, precio de venta, comisión de L 25/unidad y fotografías.
   - Botón «Pagar total comisión»: Exclusivo del Administrador para liquidar a un colaborador, registrar el pago en el historial y limpiar únicamente los artículos pagados sin borrar los datos del colaborador.
   - Fotografías: Permite tomar fotos con la cámara o seleccionarlas de la galería tanto en importaciones como en ventas.
   - Cambio de PIN Admin: Opción segura en el Panel Admin para actualizar el PIN del administrador.

Reglas estrictas de seguridad:
- Eres un asistente consultivo y de soporte. NO tienes permisos para pagar comisiones, borrar registros, alterar inventario ni modificar datos en Firebase. Si el usuario te pide ejecutar un pago o borrado, recuérdale amablemente que debe hacerlo desde el Panel de Administrador.
- Ayuda con cálculos comerciales, márgenes de ganancia, precios sugeridos y comisiones según los datos que el usuario te escriba.
- Responde siempre en español, con tono cercano, profesional y usando formato Markdown limpio.`;

export default async (req, context) => {
  // Manejo de preflight CORS
  if (req.method === 'OPTIONS') {
    return new Response(null, {
      status: 204,
      headers: {
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Methods': 'POST, OPTIONS',
        'Access-Control-Allow-Headers': 'Content-Type'
      }
    });
  }

  if (req.method !== 'POST') {
    return new Response(JSON.stringify({ error: 'Método no permitido. Solo se acepta POST.' }), {
      status: 405,
      headers: { 'Content-Type': 'application/json' }
    });
  }

  try {
    let body;
    try {
      body = await req.json();
    } catch (e) {
      return new Response(JSON.stringify({ error: 'Formato de solicitud inválido.' }), {
        status: 400,
        headers: { 'Content-Type': 'application/json' }
      });
    }

    const userMessage = (body.message || '').trim();
    if (!userMessage) {
      return new Response(JSON.stringify({ error: 'El mensaje no puede estar vacío.' }), {
        status: 400,
        headers: { 'Content-Type': 'application/json' }
      });
    }

    // Configuración de credenciales de Netlify AI Gateway o clave directa de Gemini
    const gatewayUrl = (process.env.NETLIFY_AI_GATEWAY_URL || '').replace(/\/$/, '');
    const gatewayKey = process.env.NETLIFY_AI_GATEWAY_KEY;
    const directGeminiKey = process.env.GEMINI_API_KEY;

    let apiUrl = '';
    let headers = { 'Content-Type': 'application/json' };

    if (gatewayUrl && gatewayKey) {
      apiUrl = `${gatewayUrl}/v1beta/models/gemini-2.5-flash:generateContent`;
      headers['Authorization'] = `Bearer ${gatewayKey}`;
    } else if (directGeminiKey) {
      apiUrl = `https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=${directGeminiKey}`;
    } else {
      return new Response(JSON.stringify({
        error: 'El servicio de IA no está configurado actualmente. Por favor verifica las variables de entorno en Netlify.'
      }), {
        status: 503,
        headers: { 'Content-Type': 'application/json' }
      });
    }

    // Construir historial de mensajes seguro
    const contents = [];
    if (Array.isArray(body.history)) {
      body.history.slice(-6).forEach(item => {
        if (item && item.text && (item.role === 'user' || item.role === 'model')) {
          contents.push({
            role: item.role,
            parts: [{ text: String(item.text).slice(0, 1000) }]
          });
        }
      });
    }

    contents.push({
      role: 'user',
      parts: [{ text: userMessage.slice(0, 1000) }]
    });

    const payload = {
      systemInstruction: {
        parts: [{ text: SYSTEM_PROMPT }]
      },
      contents,
      generationConfig: {
        temperature: 0.7,
        maxOutputTokens: 800
      }
    };

    const apiResponse = await fetch(apiUrl, {
      method: 'POST',
      headers,
      body: JSON.stringify(payload)
    });

    if (!apiResponse.ok) {
      const errText = await apiResponse.text();
      console.error('Gemini API Error:', apiResponse.status, errText);
      return new Response(JSON.stringify({
        error: 'Hubo una dificultad de conexión con el servicio de Gemini. Por favor intenta de nuevo.'
      }), {
        status: 502,
        headers: { 'Content-Type': 'application/json' }
      });
    }

    const data = await apiResponse.json();
    const replyText = data.candidates?.[0]?.content?.parts?.[0]?.text?.trim() ||
      'No pude generar una respuesta en este momento. Por favor reformula tu consulta.';

    return new Response(JSON.stringify({ reply: replyText }), {
      status: 200,
      headers: {
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': '*'
      }
    });

  } catch (error) {
    console.error('Server error in gemini-chat:', error.message);
    return new Response(JSON.stringify({
      error: 'Error interno del servidor al procesar la solicitud del asistente.'
    }), {
      status: 500,
      headers: { 'Content-Type': 'application/json' }
    });
  }
};
