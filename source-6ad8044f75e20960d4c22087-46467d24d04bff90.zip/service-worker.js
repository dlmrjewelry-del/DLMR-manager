// service-worker.js (alias para sw.js)
importScripts('/sw.js');
